## THESE ARE SHINY UTILITY FUNCTIONS, MOSTLY TO CREATE CUSTOMIZED UI ELEMENTS

## Utility function to add an additional class to the outer-most div of a shiny-tag
shinytag_add_class <- function(x, additional_class) {
  if (!inherits(x, "shiny.tag")) stop("x should be of class shiny.tag")
  x$attribs$class <- paste(x$attribs$class, additional_class)
  x
}

## Utility function to modify a Shiny tag with 2 children, wrapping the 2nd child in a DIV with a style attribute.
## If style = "display:inline-block;", this will have the effect of making the label inline.
## example: .iblock {display: inline-block;}   /* inline block for side-by-side UI elements  */
shinytag_wrapchild2div <- function(x, style) {
  if (length(x$children) != 2) stop("This function is designed to modify a shiny.tag with two children")
  x$children[[2]] <- div(x$children[[2]], style = style)
  x
}

## This will generate HTML code for a simple FAQ item
## sample css you can use to stylze the appearance:
## details.faq {color:brown; cursor:pointer; margin-top:1em;}
## summary.faq {color:green;}")
faq_html <- function(qtn, ans, qclass = 'faq', qa_block_class = qclass) {
  htmltools::HTML(paste0("<details class='", qa_block_class,
                         "'><summary class='", qclass, "'>", qtn,
                         "</summary>", ans, "</details>"))
}

