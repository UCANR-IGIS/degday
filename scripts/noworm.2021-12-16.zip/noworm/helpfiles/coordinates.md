### Coordinates

---

Enter coordinates in decimal degrees separated by a comma. Longitude should come first.

Example: -120.226, 36.450




