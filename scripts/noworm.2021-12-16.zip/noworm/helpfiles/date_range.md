### Date Range

---

Select a date range for the analysis. The start and end dates must be in the same calendar year.




