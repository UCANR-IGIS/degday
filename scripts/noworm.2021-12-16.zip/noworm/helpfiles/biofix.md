### Biofix

---

Select the day when larvae start to emerge from the mummy nuts.

For more info, see the Instructions tab.




