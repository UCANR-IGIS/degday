## Shiny App for the Navel Orangeworm Degree Day Calculator

## Attach packages
library(shiny)
library(shinyhelper)
library(shinybusy)
library(leaflet)
library(lubridate)
library(dplyr)
library(conflicted)
library(plotly)
library(degday)

# library(caladaptr)
# library(httr)

## The following libraries are checked but not loaded because we only need 1 or 2 functions from them
## These lines also ensure the packages will be installed when we publish the app on ShinyApps.io

requireNamespace("units")         ## returned by dd_getdata_dlyminmax_cimis
requireNamespace("cimir")         ## not called directly but a suggested package for degday that we need
requireNamespace("tidyr")         ## used by degday_utils.R
requireNamespace("sf")            ## used by degday_utils.R
requireNamespace("googlesheets4") ## used by dd_models_gsheets.R
requireNamespace("DT")            ## used for the table of milestones

# requireNamespace("scales")
# requireNamespace("purrr")


# requireNamespace("stringr")     ## review if I really need this. Just using split()? TRY TO REMOVE
requireNamespace("shinyjs")       ## needed to hide/show the weather data DIV

## Set up conflict resolution
conflict_prefer("filter", "dplyr", quiet = TRUE)
conflict_prefer("count", "dplyr", quiet = TRUE)
conflict_prefer("select", "dplyr", quiet = TRUE)
conflict_prefer("layout", "plotly", quiet = TRUE)
#conflict_prefer("dataTableOutput", "DT", quiet = TRUE)

## Load the cimis_key
cimis_key <- readLines("cimis_key.txt", warn = FALSE)
message(" - using cimis_key = ", cimis_key)

## Load in some UI convenience functions
source("shiny_utils.R")

## Download the CIMIS stations for the leaflet map
source("degday_utils.R")
cimis_stations_sf <- cimis_active_sf(cimis_key)

## Load function to download the phenology tables
source("dd_models_gsheets.R")

# ## Download models and phenology tables from Google Sheets MOVED TO INSIDE SERVER()
message(" - downloading the Google Sheet for the first time this R process")
dd_models_lst <- dd_models_gsheet(shiny_only = TRUE)
download_time <- Sys.time()
grow_mod_names <- as.character(sapply(dd_models_lst$models_lst, function(x) paste0(x$species, " (", x$crop, ")")))
grow_mod_def <- "Navel Orangeworm (almonds,pistachios)"

## This was an attempt to create dynamic help text, but it won't work with ShinyHelper.
## Look at shinyalert or that package I use for the goat grass popups.
## biofix_help_chr <- "Biofix is really important"

## Create constants for weather data sources
WD_LIVNEH <- "CalAdapt (Livneh)"
WD_WWO <- "World Weather Online"
WD_CIMIS <- "CIMIS (nearest station)"
wd_src_seas <- c(WD_CIMIS, WD_WWO)
wd_src_ntd <- c(WD_WWO)
wd_src_elevenplus <- WD_LIVNEH
wd_src_hist <- WD_LIVNEH

## Create some reusable constants for plotly
# plt_xlab_none <- list(title = "") DELETE

## Setup UI
ui <- fluidPage(
  tags$head(
    tags$style(type="text/css",
        ".space_above_below {margin-top:0.5em; margin-bottom:0.5em;}
        div.vertical_padding_2 {margin-top:2em; margin-bottom:2em;}
        h2,h3,h4 {font-weight:bold;}
        h4.space-above {margin-top:2em;}
        p.heading-tagline {font-weight:bold; font-size:140%; font-style:italic; color:#888; margin-bottom:0;}
        .iblock {display: inline-block;}
        .head300 {display: inline-block; width:300px;}
        .plot-note {color:#888;}
        div.indented1 {margin-left:1em;}
        div.error-msg {color:red; margin:1em 0;}
        div#shiny-notification-panel {right:0; left:0; margin:0 auto;}
        .leaflet-container {cursor: pointer !important;}
        .shinyhelper-container {display:inline-block !important; position:relative !important; margin-left:1em !important;}
        summary.faq {margin-top:1.2em; margin-bottom:1.2em;}
        details.faq {cursor:pointer;}
        div.shaded-textbox {margin-left:2em; background-color:#ddd; border:2px solid gray; padding:10px;}
        div.shiny-options-group {margin-left:1em;}
        @media print {
          div.screen-only {display: none;}
        }"),
    includeHTML("gtag_noworm.js")
  ),

  ## We put the following tag in the body of the HTML document, rather than the head, so it doesn't
  ## get over-written by shinyhelper.css. This is needed to move the shinyhelp info buttons
  ## closer to the label rather than the far right edge of the column
  # tags$style(type="text/css",
  #            ".shinyhelper-container {display: inline-block; position: relative; margin-left:1em;}
  #              div.dt-buttons {margin-top:5px; float:right;}"),

  use_busy_spinner(spin = "hollow-dots", position = "bottom-left"),

  titlePanel(title = "Navel Orangeworm Development Calculator (DRAFT)",
             windowTitle = "Navel Orangeworm Calc"),

  shinyjs::useShinyjs(),

  fluidRow(
    column(12,
           tags$p("This calculator predicts the development stages of Navel Orangeworm at a specific location based on temperature data and growth model based on degree days. For more information, see the 'Instructions' tab."),
           tags$p(tags$strong("CAUTION", .noWS = "after"),
                  ": this app is still under development and should not be used for crop management.",
                  style="text-align:center; color:crimson; font-weight:bold; padding:5px; width:50%; margin:1em auto; border:2px solid crimson; background-color:yellow;")
    )
  ),

  navbarPage(
    "",  # navigation bar title, leave blank

    tabPanel("Calculator",
             div(class = 'screen-only',

                 h3("1. Select Location"),

                 div(leafletOutput("mymap", height = 400), style = "max-width:600px; margin-bottom:1em;"),

                 textInput("in_coordstxt", label = "Coordinates: ", placeholder = "-120.425, 37.365") %>%
                   shinytag_add_class("space_above_below") %>%
                   shinytag_add_class("iblock") %>%
                   helper(type = "markdown",
                          icon = "info-circle",
                          content = "coordinates",
                          buttonLabel = "OK",
                          size = "s"),

                 textOutput("out_coordstxt_errmsg") %>% shinytag_add_class("error-msg"),

                 h3("2. Report options"),

                 # dateRangeInput("in_dtrange", label = "Date range for the analysis:",
                 #                start = make_date(year(now()), 1, 1),
                 #                end = make_date(year(now()), 10, 31),
                 #                min = make_date(year(now()), 1, 1),
                 #                max = make_date(year(now()), 12, 31)) %>%
                 #   shinytag_add_class("iblock") %>%
                 #   helper(type = "markdown",
                 #          icon = "info-circle",
                 #          content = "date_range",
                 #          buttonLabel = "OK",
                 #          size = "s"),

                 ## Note that 'selected' and 'choices' will be initialized in server()
                 selectInput("in_growth_model", "Species & Crop", width = "500px", choices = grow_mod_names,
                             selected = grow_mod_def) %>%
                   shinytag_add_class("iblock") %>%
                   helper(type = "markdown",
                          icon = "info-circle",
                          content = "growth-models",
                          buttonLabel = "OK",
                          size = "m"),

                 dateInput("in_biofix", label = "Biofix date",
                           value = make_date(year(now()), 1, 1),
                           min = make_date(year(now()), 1, 1),
                           max = make_date(year(now()), 12, 31)) %>%
                   shinytag_add_class("iblock") %>%
                   helper(type = "markdown",
                          icon = "info-circle",
                          content = "biofix",
                          buttonLabel = "OK",
                          size = "s"),

                 dateInput("in_enddate", label = "End date",
                           value = make_date(year(now()), 10, 31),
                           min = make_date(year(now()), 1, 1),
                           max = make_date(year(now()), 12, 31)) %>%
                   shinytag_add_class("iblock") %>%
                   helper(type = "markdown",
                          icon = "info-circle",
                          content = "enddate",
                          buttonLabel = "OK",
                          size = "s"),


                 checkboxGroupInput("in_phen_stages", "Predict Phenology Events",
                                    inline = FALSE,
                                    width = "500px"),

                 textOutput("out_phen_errmsg") %>% shinytag_add_class("error-msg"),

                 h3("3. Weather data") %>% shinytag_add_class("head300"),

                 actionButton(inputId = "btn_weather_toggle", label = "", icon = icon("cog")),

                 div(
                   div(
                     selectInput("in_wd_seashist", label = "Start date to yesterday:",
                                 choices = wd_src_seas, selected = wd_src_seas[1]),
                     selectInput("in_wd_seasntd", label = "Next 10 days (if needed):",
                                 choices = wd_src_ntd, selected = wd_src_ntd[1]),
                     class = "indented1",
                     selectInput("in_wd_elevenplus", label = "11+ days (if needed):",
                                 choices = wd_src_elevenplus, selected = wd_src_elevenplus[1]),
                     class = "indented1",

                   ),
                   div(
                     selectInput("in_histref_src", label = "Historical reference: (are we adding this?)",
                                 choices = wd_src_hist, selected = WD_LIVNEH) %>%
                       shinytag_add_class("iblock") %>%
                       helper(type = "markdown",
                              icon = "info-circle",
                              content = "hist_ref",
                              buttonLabel = "OK",
                              size = "m"),
                     # sliderInput("in_histref_dt", label = "Historical date range",
                     #             min = 1950, max = 2010,
                     #             value = c(1980, 2010),
                     #             step = 1, sep = ""),
                     class = "indented1"
                   ),

                   id = "weather_opts_div"
                 ),

                 h3("4. Report"),
                 div(actionButton("cmdrun", "Run!"), style = "margin-left:2em;"),
                 textOutput("out_txt_cmdrun_errmsg") %>% shinytag_add_class("error-msg")

             ),   ## end of div - don't print!

             conditionalPanel(
               condition = "output.showrpt",
               hr(),
               h4("Results", class = "space-above"),
               uiOutput("out_ui_reporthead"),
               p(),
               plotlyOutput("out_ply_add", width = "800px"),
               uiOutput("out_ui_plotnotes"),

               h4("Phenology Events", class = "space-above"),
               DT::dataTableOutput("milestones_tbl", width = "600px"),

               div(class = 'screen-only',
                   HTML("<p style=\"text-align:center; margin-top:2em; width:800px;\"><a href=\"javascript:window.print()\">"),
                   icon("print"), HTML("</a></p>")
                   )

             ),  ## end conditional panel
             br(), br(), br()

    ), ## end tab panel calculate

    tabPanel("Instructions",
             h3("Instructions"),
             # faq_html("Why did the chicken", "To cross the road"),
             HTML("<p style='font-style:italic; color:crimson;'>For development purposes, the instructions below are coming from a Google Doc. To edit them, please edit the <a href='https://docs.google.com/document/d/13tz41oIGxUF3yolOILWyKUGH3KVoNo1bqwqhBRFT7As/edit?usp=sharing' target='_blank'>Google Doc</a>. It can take up to 5 minutes for changes in the Google Doc to be reflected below. Once we are happy with the instructions, they'll be converted to HTML.</p>"),
             tags$iframe(src="https://docs.google.com/document/d/e/2PACX-1vQZ5thrFYq0mH6iI33k87qkQGoKnHhU94xMNVS__0RDr9UHG_h3uROrOZNvrONRi7_EUerCaLvf7JSA/pub?embedded=true",
                         width="900px",
                         height="2000px"
             )
    ),

    tabPanel("Resources",
             h3("Resources"),
             p("Optional place to put extension resources")
    )

  )

)

server <- function(input, output) {

  ## Update the choices and selection for the growth models
  ## We put this here rather than in ui() so that whenever a new instance of the app is created on ShinyApps.io,
  ## it will download the model list from Google Sheets and refresh the select Input choices.
  ## If we downloaded the Google Sheet outside server(), it would only execute once when the app is started, and
  ## you would have to wait for the app to shut down for a refresh. Once the model selections are settled, we
  ## can load this from a CSV file.
  ## 1) Download models and phenology tables from Google Sheets

  ## If it's been more than 5 seconds since the last download time, get it again because this could be a new session.
  if (difftime(Sys.time(), download_time, units = "sec") > 10) {
    cat(" - downloading the Google Sheet again \n")
    dd_models_lst <<- dd_models_gsheet(shiny_only = TRUE)
    download_time <<- Sys.time()
    grow_mod_names <<- as.character(sapply(dd_models_lst$models_lst, function(x) paste0(x$species, " (", x$crop, ")")))
    grow_mod_def <- "Navel Orangeworm (almonds,pistachios)"
    ## 2) Update the selectInput control
    updateSelectInput(inputId = "in_growth_model", choices = grow_mod_names, selected = grow_mod_def)
  }

  # ## Create some reactive vals for values that will be downloaded
  loc_xy <- reactiveVal()           ## Location
  phen_tbl <- reactiveVal()
  minmax_dd_tbl <- reactiveVal()
  show_report <- reactiveVal(FALSE)

  # tu_strtntd_cur <- reactiveVal()   ## Complete TU curve from start to next ten days
  # tu_strtend_hist <- reactiveVal()  ## Complete TU curve from start to end for historical baseline

  ## Create a reactive object that has the model parameters for the currently selected species-crop
  dd_params_lst <- reactive(
    dd_models_lst$models_lst[[which(input$in_growth_model == grow_mod_names)]]
  )

  ## Assemble the parameters needed for dd_calc
  ## dd_params_lst <- dd_models_lst$models_lst[[which(input$in_growth_model == grow_mod_names)]]


  #show_report(FALSE)

  ## Add an observer to watch out for clicks on the shinyhelper buttons.
  ## The md files will be located in the default 'helpfiles' subdir
  observe_helpers()

  ## Initially hide the 'weather options' div
  shinyjs::hide(id = "weather_opts_div", anim = TRUE)

  ## Disable controls I'm not using at the moment
  shinyjs::disable(id = "in_wd_seasntd")
  shinyjs::disable(id = "in_wd_elevenplus")
  shinyjs::disable(id = "in_histref_src")

  ## Create the expression that toggles visibility of the report conditional panel
  output$showrpt <- reactive({
    show_report()
  })
  outputOptions(output, "showrpt", suspendWhenHidden = FALSE)

  ## Set the initial map extent (called once but never called again after that)
  output$mymap <- renderLeaflet({
    grp_name_cimis <- "Active CIMIS Stations"
    usgs_wms_imgtopo <- "https://basemap.nationalmap.gov/arcgis/services/USGSImageryTopo/MapServer/WmsServer"
    usgs_att <- paste0("<a href='https://www.usgs.gov/'>", "U.S. Geological Survey</a> | ",
                       "<a href='https://www.usgs.gov/laws/policies_notices.html'>", "Policies</a>")
    leaflet() %>%
      addTiles(group = "Open Street Map") %>%
      addWMSTiles(usgs_wms_imgtopo, group="Satellite (USGS)", attribution=usgs_att, layers="0") %>%
      addProviderTiles("Esri.WorldImagery", group="Satellite (ESRI)") %>%
      addCircleMarkers(data = cimis_stations_sf %>% select(title), radius = 3, stroke = FALSE, fillColor = "#8E44AD", fillOpacity = 0.75, popup = ~title, group = grp_name_cimis) %>%
      setView(-120.2, 36.4, zoom=6) %>%
      addLayersControl(
        baseGroups = c("Open Street Map", "Satellite (USGS)", "Satellite (ESRI)"),
        overlayGroups = grp_name_cimis,
        options = layersControlOptions(collapsed = FALSE)) %>%
      hideGroup(grp_name_cimis)
  })

  ## The following will run whenever input$mymap_click changes
  observeEvent(input$mymap_click, {
    ## Update loc_xy
    loc_xy(c(input$mymap_click$lng, input$mymap_click$lat))  ## will trigger an observeEvent() to update the marker on the map
    updateTextInput(inputId = "in_coordstxt", value = paste(round(loc_xy()[1],5), round(loc_xy()[2],5), sep = ", "))
  })

  ## observe the 'Weather Settings' button being pressed
  observeEvent(input$btn_weather_toggle, {
    if(input$btn_weather_toggle %% 2 == 1){
      shinyjs::show(id = "weather_opts_div", anim = TRUE)
    }else{
      shinyjs::hide(id = "weather_opts_div", anim = TRUE)
    }
  })

  # ## The following will run whenever in_coordstxt is updated
  observeEvent(input$in_coordstxt, {

    ## Stop here if input$in_coordstxt = ""
    req(input$in_coordstxt != "")

    ## input$in_coordstxt will always be a character of length 1, so the
    ## following will always be a list of length 1

    # coords_split <- stringr::str_split(input$in_coordstxt, ",")
    coords_split <- strsplit(input$in_coordstxt, ",")

    ## Only continue if the first element has two elements (meaning exactly one ',')
    if (length(coords_split[[1]]) == 2) {
      ## Parse out the coordinates
      mycoords <- coords_split[[1]] %>% trimws() %>% as.numeric()

      if (NA %in% mycoords) {
        output$out_coordstxt_errmsg <- renderText("Enter coordinates in decmial degrees separated by a comma. Example: -120.226, 36.450")
      } else {
        output$out_coordstxt_errmsg <- renderText(NULL)
        loc_xy(c(mycoords[1], mycoords[2]))
      }

    }

    ## Get rid of any error message below the cmd_run button
    output$out_txt_cmdrun_errmsg <- renderText(NULL)

    show_report(FALSE)

  })

  ## The following will run whenever loc_xy() changes. It will update the leaflet map.
  observeEvent(loc_xy(), {

    req(loc_xy()[1] >= -180 && loc_xy()[1] <= 180)
    req(loc_xy()[2] >= -90 && loc_xy()[1] <= 90)

    ## Clear existing markers and add a marker at the new location
    leafletProxy('mymap') %>%
      #clearMarkers() %>%
      removeMarker("loc") %>%
      addMarkers(lng = loc_xy()[1],
                 lat = loc_xy()[2],
                 layerId = "loc")
    show_report(FALSE)
  })

  ## The following will run whenever in_growth_model changes
  ## It will update the phenology stage predictions
  observeEvent(input$in_growth_model, {

    ## Get the model_id that corresponds to the selected model name
    grow_mod_id <- names(dd_models_lst$models_lst)[input$in_growth_model == grow_mod_names]

    ## Make a table for the phenology stages
    dd_thismod_phen_df <- dd_models_lst$phen_tbl %>%
      filter(model_id == grow_mod_id) %>%
      arrange(order) %>%
      transmute(event = paste0(event_name, " (", dd, " DD)"),
                dd = paste0(event_name, "|", dd))

    updateCheckboxGroupInput(
      inputId = "in_phen_stages",
      choices = setNames(as.list(dd_thismod_phen_df$dd),
                         dd_thismod_phen_df$event),
      selected = dd_thismod_phen_df$dd
    )

    if (nrow(dd_thismod_phen_df) == 0) {
      output$out_phen_errmsg <- renderText("No phenology events are available for this species and crop")
    } else {
      output$out_phen_errmsg <- renderText(NULL)
    }

    show_report(FALSE)

  })

  ## Hide the report if anything changes
  observeEvent(list(input$in_biofix, input$in_enddate, input$in_phen_stages,
                    input$in_wd_seashist, input$in_wd_seasntd, input$in_wd_elevenplus), {
                      cat(" - something changed! hiding the report\n")
                      show_report(FALSE)
    }
  )

  observeEvent(input$cmdrun, {

    ## Location check - missing
    if (is.null(loc_xy())) {
      output$out_txt_cmdrun_errmsg <- renderText("No location selected.")
      return(NULL)
    } else {
      output$out_txt_cmdrun_errmsg <- renderText(NULL)
    }

    ## Location check - within bounds
    ## COMING SOON

    ## Date check - start and end date
    # dt_start <- input$in_dtrange[1]
    # dt_end <- input$in_dtrange[2]
    dt_start <- input$in_biofix
    dt_end <- input$in_enddate
    if (dt_start >= dt_end) {
      output$out_txt_cmdrun_errmsg <- renderText("The biofix date should come before the end date.")
      return(NULL)
    }

    ## Date check - biofix date within start and end date
    dt_biofix <- input$in_biofix
    if (dt_biofix > dt_end || dt_biofix < dt_start) {
      output$out_txt_cmdrun_errmsg <- renderText("The biofix date must be between start and end dates.")
      return(NULL)
    }

    show_spinner()

    ## Fetch Temp Data - Start date to yesterday
    dt_today <- Sys.Date()
    if (dt_start <= (dt_today - 1)) {
      message(" - Going to get data from the start date until yesterday")
      if (input$in_wd_seashist == WD_CIMIS) {
        message(" - querying CIMIS")
        minmax_tbl <- dd_fetch_cimis(loc = loc_xy(),
                                 start_date = dt_start,
                                 end_date = min(dt_today - 1, dt_end),
                                 api_key = cimis_key,
                                 debug = TRUE)
        message(" - got ", nrow(minmax_tbl), " rows of data \n", sep = "")
        ## We will igore Qc for now

      } else {
        output$out_txt_cmdrun_errmsg <- renderText("Sorry. That weather data source is not yet supported")
        return(NULL)
      }
    }

    ## Fetch Temp Data - Next ten days
    if (dt_end >= dt_today) {
      output$out_txt_cmdrun_errmsg <- renderText("Sorry. The 10-day forecast is not yet ready")
      return(NULL)
    }

    ## Fetch Temp Data - 11+ days (if needed)
    if (dt_end >= (dt_today + 10)) {
      output$out_txt_cmdrun_errmsg <- renderText("Sorry. The 11+ forecast is not yet ready")
      return(NULL)
    }

    hide_spinner()

    ## At this point we should have some data in minmax_tbl!

    ## Generate the "About the Report" box
    output$out_ui_reporthead <- renderUI({
      HTML(paste0("<div class='shaded-textbox' style='width:800px; margin-bottom:2em;'>",
                  "<p><span style='font-weight:bold;'>Species and Crop:</span> ", input$in_growth_model, "</p>",
                  "<p><span style='font-weight:bold;'>Location:</span> ", paste(round(loc_xy(),4), collapse = ", " ), "</p>",
                  # "<p><span style='font-weight:bold;'>Date Range:</span> ", format(input$in_dtrange[1], '%B %d, %Y'),
                  # " to ", format(input$in_dtrange[2], '%B %d, %Y'), "</p>",
                  "<p><span style='font-weight:bold;'>Biofix date:</span> ", format(input$in_biofix, '%B %d, %Y'), "</p>",
                  "<p><span style='font-weight:bold;'>End date:</span> ", format(input$in_enddate, '%B %d, %Y'), "</p>",
                  "<p><span style='font-weight:bold;'>Weather sources:</span></p>",

                  "<p style='margin-left:1em;'><span style='font-style:italic;'> Start date to yesterday:</span> ", input$in_wd_seashist, "</p>",
                  "<p style='margin-left:1em;'><span style='font-style:italic;'> Next 10 days:</span> ", input$in_wd_seasntd, "</p>",
                  "<p style='margin-left:1em;'><span style='font-style:italic;'> 11+ days:</span> ", input$in_wd_elevenplus, "</p>",
                  "<p><span style='font-weight:bold;'>Report date:</span> ", format(Sys.Date(), "%B %d, %Y"), "</p>",
                  "</div>")
      )
    })

    ## Add cumulative degree days to the table and save it to the reactiveVal
    minmax_dd_tbl(minmax_tbl %>%
                    mutate(tmin = as.numeric(tmin), tmax = as.numeric(tmax)) %>%
                    mutate(dd = dd_calc(daily_min = tmin,
                          daily_max = tmax,
                          thresh_low = dd_params_lst()$thresh_low,
                          thresh_up = dd_params_lst()$thresh_up,
                          method = dd_params_lst()$method,
                          cutoff = dd_params_lst()$cutoff,
                          cumulative = TRUE,
                          interpolate_na = TRUE)) %>%
                    mutate(source = "CIMIS"))

    ## Generate the phenology milestones tibble, and save it in a reactiveVal object
    if (is.null(input$in_phen_stages)) {
      phen_tbl(NULL)

    } else {
      cum_dd <- 0
      milestones_df <- NULL

      for (i in 1:length(input$in_phen_stages)) {
        line_params <- strsplit(input$in_phen_stages[i], split = "\\|")[[1]]
        cum_dd <- cum_dd + as.numeric(line_params[2])
        idx <- min(which(minmax_dd_tbl()$dd > cum_dd))

        milestones_df <- rbind(milestones_df,
                               data.frame(event = line_params[1],
                                          dd = as.numeric(line_params[2]),
                                          date = minmax_dd_tbl()[idx,"date", drop = TRUE],
                                          cumulative.dd = round(minmax_dd_tbl()[idx,"dd", drop = TRUE])))
      }
      phen_tbl(milestones_df)
    }

    ## Generate the "Plot notes" box
    output$out_ui_plotnotes <- renderUI({
      HTML(paste0("<div style='width:800px; margin-left:2em;'>",
                  "<p class='plot-note'>Notes</p>",
                  "<ul>",
                  "<li class = 'plot-note'>", "Degree days are computed using the ", dd_params_lst()$method,
                  " method with a ", dd_params_lst()$cutoff, " cutoff, a lower threshold of ", dd_params_lst()$thresh_low, "&#176;F, and an upper threshold of ",
                  dd_params_lst()$thresh_up, "&#176;F.", "</li>",
                  "</ul></div>")
      )
    })

    show_report(TRUE)

  })  # observeEvent(input$cmdrun)


  ## Generate the plot for the cumulative DD curve for this season
  output$out_ply_add <- renderPlotly({
    ## Do nothing if phen_tbl() hasn't been initialized
    req(minmax_dd_tbl())

    my_ply <- plot_ly(minmax_dd_tbl(), x = ~date, y = ~dd) %>%
      add_lines(name = "cumulative degree days") %>%
      layout(title = paste0("Cumulative Degree Days for ", dd_params_lst()$species, "\n",
                            format(isolate(input$in_biofix), "%B %d"), " - ",
                            format(isolate(input$in_enddate), "%B %d, %Y")),
             xaxis = list(title = "",
                          type = 'date',
                          dtick = "M1",
                          tickfont = list(size = 10),
                          tickformat = "%b<br>%Y"),
             yaxis = list(title = "degree days"))

    ## Add drop lines for the biofix ??

    ## Add drop lines for the phenology milestones
    if (!is.null(phen_tbl())) {
      my_colors <- c("green", "blue", "orange", "purple")
      for (i in 1:nrow(phen_tbl())) {
        vline_xs <- rep(phen_tbl()[i,"date",drop=T], 2)
        vline_ys <- c(0, phen_tbl()[i,"cumulative.dd",drop=T])
        my_ply <- my_ply %>% add_lines(x = vline_xs, y = vline_ys,
                                       line = list(color = my_colors[i], dash = "dot"),
                                       name = phen_tbl()[i,"event"])
      }
    }

    ## Return the final plotly object
    my_ply

  })

  ## Update the milestones table whenever phen_tbl() changes
  output$milestones_tbl <- DT::renderDataTable({
    ## Do nothing if phen_tbl() hasn't been initialized
    ## req(phen_tbl()) Lets see this might be better to let it go and render NULL

    DT::datatable(phen_tbl(),
                  rownames = FALSE,
                  options = list(paging = FALSE,
                                 searching = FALSE,
                                 info = FALSE,
                                 fixedColumns = TRUE,
                                 autoWidth = TRUE,
                                 ordering = FALSE),
                  class = "display"
    )

  })

}

# Run the application
shinyApp(ui = ui, server = server)

