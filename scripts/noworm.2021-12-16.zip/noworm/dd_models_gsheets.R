dd_models_gsheet <- function(shiny_only = TRUE) {

  if (!requireNamespace("googlesheets4")) stop("googlesheets4 is a required package")
  if (!require(dplyr)) stop("dplyr is a required package")

  sheet_id <- "1N8MKd6rsvs_PFwHDpPbW26_1zSm9FOIBRiswAOYgtRk"
  googlesheets4::gs4_deauth()

  ## Download the species-crop dd models
  dd_models_tbl <- googlesheets4::read_sheet(ss = sheet_id, sheet = "dd_models")

  if (shiny_only) {
    dd_models_tbl <- dd_models_tbl %>% filter(use_shiny == 1)
  }

  ## Convert them to a list
  dd_models_sub_tbl <- dd_models_tbl %>% select(-model_id, -notes)

  models_lst <- setNames(split(dd_models_sub_tbl, seq(nrow(dd_models_sub_tbl))), dd_models_tbl$model_id)

  # x <- split(dd_models_sub_tbl, seq(nrow(dd_models_sub_tbl)))
  # y <- setNames(x, dd_models_tbl$model_id)

  ## Download the phenology table
  phen_tbl <- googlesheets4::read_sheet(ss = sheet_id, sheet = "phenology")

  ## Return model params and phenology table as list elements
  list(models_lst = models_lst, phen_tbl = phen_tbl)


}
