cimis_active_sf <- function(cimis_key, debug = TRUE) {

  ## Utility function for downloading the active CIMIS stations
  ## This function is called from app.R.
  ## We can assume dplyr is loaded

  if (!requireNamespace("cimir")) stop("This function requires the cimir package")
  if (!requireNamespace("sf")) stop("This function requires the sf package")
  if (!requireNamespace("dplyr")) stop("This function requires the dplyr package")

  ## See if the active stations have already been fetched this R session
  stations_active_tbl <- getOption("cimis_stations", NA)

  ## Fetch them if needed
  if (identical(stations_active_tbl, NA)) {

    if (debug) message(paste0("Setting CIMIS API Key: ", cimis_key, "\n"))
    cimir::set_key(cimis_key)

    if (debug) message("Getting the table of active CIMIS stations...", appendLF = FALSE)
    stations_all_tbl <- cimir::cimis_station()   ## this is really fast
    if (debug) message("Done.")

    stations_active_tbl <- stations_all_tbl %>%
      filter(IsActive == "True") %>%
      select(StationNbr, Name, HmsLatitude, HmsLongitude) %>%
      distinct() %>%
      transmute(station_id = as.numeric(StationNbr),
             name = Name,
             lon = as.numeric(gsub("^.*/ ", "", HmsLongitude)),
             lat = as.numeric(gsub("^.*/ ", "", HmsLatitude)))

    options(cimis_stations = stations_active_tbl)
  } else {
    if (debug) message(" - using active CIMIS stations table in memory ")
  }

  ## Return a SF object
  stations_active_tbl %>%
    mutate(title = paste0(name, " (#", station_id, ")"),) %>%
    select(title, lon, lat) %>%
    sf::st_as_sf(coords = c("lon", "lat"), crs = 4326)

  # ## Filter just the active ones, and make is a sf object
  # stations_all_tbl %>%
  #   dplyr::filter(IsActive == "True") %>%
  #   dplyr::select(StationNbr, Name, HmsLatitude, HmsLongitude) %>%
  #   dplyr::distinct() %>%
  #   dplyr::transmute(station_id = as.numeric(StationNbr),
  #                 name = Name,
  #                 title = paste0(Name, " (#", as.numeric(StationNbr), ")"),
  #                 lon = as.numeric(gsub("^.*/ ", "", HmsLongitude)),
  #                 lat = as.numeric(gsub("^.*/ ", "", HmsLatitude))) %>%
  #   sf::st_as_sf(coords = c("lon", "lat"), crs = 4326)

}




